<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="assets/images/favicon/favicon.png" rel="icon">

<!-- Fonts
    ============================================= -->
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,400i,500,500i,600,600i,700,700i,800%7CRoboto:300i,400,400i,500,500i,700" rel="stylesheet" type="text/css">

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">

<!-- RS5.0 Main Stylesheet -->
<link rel="stylesheet" type="text/css" href="assets/revolution/css/settings.css">
<link rel="stylesheet" type="text/css" href="assets/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="assets/revolution/css/navigation.css"> 

    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <script type="text/javascript" src="assets/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script> 

<!-- Document Title
    ============================================= -->
<title>Hyperspace</title>
</head>
<body>
<div class="preloader">
	<div class="reverse-spinner"></div>
</div><!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="wrapper clearfix">
<header id="navbar-spy" class="header header-1 header-transparent">
	<nav id="primary-menu" class="navbar navbar-expand-lg navbar-light navbar-bordered">
		<div class="container">
			<a class="navbar-brand" href="index.php">
				<img class="logo logo-light" src="assets/images/logo/logo.png" alt="Hyperspace Logo"> 
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
							
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="navbarContent">
				<ul class="navbar-nav ml-auto">
				<!-- Home Menu-->
<li class=" ">
    <a href="#"  class=" menu-item">Home</a>
</li>
<!-- li end -->

<!-- Community Menu -->
<li class="">
    <a href="#"  class=" menu-item" data-hover="pages">Community</a>
</li>
<!-- li end -->
<!-- Hackathons Menu-->
<li class="">
    <a href="#" class=" menu-item" >Hackathons</a>
   
</li>
<!-- li end -->
<!-- Resources Menu-->
<li class="">
    <a href="#"  class=" menu-item">Resources</a>
    
</li>
<!-- li end -->
				<div class="module-container">
				<!-- Module Attend  -->
<div class="module module-consultation pull-left">
	<a class="btn" href="#">Attend</a>
</div>				


			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container -->
	</nav>
</header>




<!-- Page Title #1
============================================= -->
<section id="page-title" class="page-title bg-overlay bg-overlay-dark bg-parallax">
    <div class="bg-section">
        <img src="https://lh3.googleusercontent.com/gzCuGmJmMs_NYpZzJM4su49ClzxMwsAWWi_lidFO4XcLNhZsTkSxg7HFSJfrN-E6Ray357tHNKiOJA9bGwtN8PI17SZ8Bto1bKyDMH40876gxdOzx2af33Xdq1W6M4mllaxOaNwdtlpX8pzteKhHzbBOEl-aQ7b1Dql7RLS1Lq0t-rLytu1DgzPNxlcLPtwNwuIMWIuR-EPFTmetuuSji_pvVxnMy9zf6PyCtuA7Ra1m_UBjI995WlSOGbLxSQR4zOPZ_ONbD43UsoZzMZ25jBsOdRa53Ytnq5IzO5tC1_fQlQpt1LTN_WaVOIiDCuav06Dku7ASI0XzBqTwgkRtMehXYaj4xhlf6oiR3Ih64-g_oUsEsntldbwGwu0lMXrZrv6DK3MuyQlQKGtcVWId8S59SdjAy76yl9RsAgroBG0NWuzmSfnOguUijFr7aHrvFaUyP29WiaoTYLalZCpn8bLxgoOGRhsxmaxT5iToRBakqPBv5Sv2xBJdVC9D0zvGGNQoka-_vNjziqfCrb7Byju2q6JYTfknoVVfqLsc3PfCjwxKfpTkXoCnXqyeYLqJfS8mhafriTTKR9mHYx4NwJ-5-pLYdsek2UjeLu-KQCHexxo0BMjD55RouOD-CUjrVoVsBdFaD0MCReAiXD-n-bregbDq3_5_82ETVOgJYQUuheKFmWjYEtSji-f7V-fqX2zLxrKUOZLUG2g-lnIRTO_08g=w1006-h494-no" alt="Background" />
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-8 offset-lg-2">
                <div class="title text-center">
                    <div class="title--heading">
                        <h1>about us</h1>
                    </div>
                    <div class="clearfix"></div>
                    <ol class="breadcrumb d-flex justify-content-center">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">about</li>
                    </ol>
                </div>
                <!-- .title end -->
            </div>
            <!-- .col-lg-8 end -->
        </div>
        <!-- .row end -->
    </div>
    <!-- .container end -->
</section>
<!-- #page-title end -->


<!-- about  #1
============================================= -->
<section id="about1" class="about about-1 bg-gray pt-110 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-9 offset-lg3">
                <div class="heading">
                    <h4 class="heading--title">Who We Are</h4>
                </div>
                <div class="about--text">
                    <p>      The Build Actual Stuff Hackathon (BASH) is a distro of the MLH Local Hackday Event unique to the African Tech Ecosystem specifically geared towards students in tertiary institutions. Its major objective is to help students hackers and developers validate their skills and learning process using the best resources and tools available from industry expert from around the globe. <br>
                        The goal is to create a hackathons with an all-inclusive environment free from pressure and uniquely different from Traditional Hackathons.We are committed to the goal of converting lifelong learners into actual solution Builders.
                         </p>
                </div>
                <div class="heading">
                    <h4 class="heading--title">How BASH works</h4>
                </div>
                <div class="about--text">
                    <p>
                        The Build Actual Stuff Hackathon pilot program is a Twelve-Hour Hackathon series that will run through the months of May to September, offering various activities from codelabs to workshops on selected technologies, design and build contests of which winners get the opportunity to partake in the Kings of the BASH contest which happens at the end of the entire hackathon season. <br>
                        Application are currently open for Organizers in select campuses in Nigeria. <a href="#">Apply Now</a> <br> <br>
                        The best hackers from each campus/school will get the opportunity to compete amongst each other to secure the trophy and bragging rights as kings of the season. 
                        Judges of the Hackathon which will also be based on selections from applications and occur virtually with eaach Campus with its own unique combination of Judges  
                    </p>
                </div>
                
            </div>
            <!-- .col-lg-6 end -->
         
        </div>
      </div>
    <!-- .container end -->
</section>
<!-- #about1 end -->


<!-- new-sponsor-div #1
============================================= -->
<section id="cta1" class="cta cta-1 bg-theme">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-9 col-lg-10">
                <h3>Looking to become a part of this awesome movement? Become a sponsor</h3>

            </div>
            <!-- .col-lg-10 -->
            <div class="col-sm-2 col-md-3 col-lg-2 text-right">
                <a href="#" class="btn btn--white btn--bordered btn--rounded">Sponsor</a>
            </div>
            <!-- .col-lg-2 -->
        </div>
        <!-- .row -->
    </div>
    <!-- .container -->
</section>
<!-- #new-sponsor-div end -->

<!-- Footer #1
============================================= -->
<footer id="footer" class="footer footer-1">
	<!-- Widget Section
	============================================= -->
	<div class="footer-widget">
		<div class="container">
			<div class="row clearfix">
				<div class="col-12 col-md-6 col-lg-3 footer--widget widget-about">
					<div class="widget-content">
						<img class="footer-logo" src="assets/images/logo/logo.png" alt="logo">
						<p>Grooming students into experts, ready to challenge the ever growing tech-sphere. Finding talents around Africa and making them stars. </p>
						<div class="social-icons">
							<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
							<a href="https://twitter.com/HyperspaceAfric" class="twitter"><i class="fa fa-twitter"></i></a>
                            <a href="https://instagram.com/hyperspaceafrica" class="instagram"><i class="fa fa-instagram"></i></a>
							<a href="#" class="slack"><i class="fa fa-slack"></i></a>
							<a href="#" class="github"><i class="fa fa-github"></i></a>
                        </li>
						</div>
					</div>
				</div><!-- .col-md-3 end -->
				<div class="col-12 col-sm-4 col-md-6 col-lg-2 footer--widget widget-links">
					<div class="widget-title">
						<h5>About</h5>
					</div>
					<div class="widget-content">
						<ul>
							<li><a href="./about.php">About Us</a></li>
							<li><a href="./meet-the-team.php">Meet Our Team</a></li>
							<li><a href="#">Latest News</a></li>
							<li><a href="" data-toggle="modal" data-target="#modalPush">Contact Us</i></li>
						</ul>
					</div>
				</div><!-- .col-md-2 end -->
				
				<div class="col-12 col-sm-8 col-md-6 col-lg-2 footer--widget widget-links widget-links-inline">
					<div class="widget-title">
						<h5>Resources</h5>
					</div>
					<div class="widget-content">
						<ul>
							<li><a href="#">Code of Conduct</a></li>
							<li><a href="#">Find a Hackathon</a></li>					
						</ul>
					</div>
				</div><!-- .col-md-4 end -->

				<div class="col-12 col-sm-8 col-md-6 col-lg-2 footer--widget widget-links widget-links-inline">
									<div class="widget-title">
										<h5>Info</h5>
									</div>
									<div class="widget-content">
										<ul>
											<li><a href="#">Become an Organiser</a></li>
											<li><a href="#">FAQs</a></li>
										</ul>
									</div>
								</div><!-- .col-md-4 end -->

				<div class="col-12 col-md-6 col-lg-3 footer--widget widget-newsletter">
					<div class="widget-title">
						<h5>Stay Updated</h5>
					</div>
					<div class="widget-content">
						<form class="form-newsletter mailchimp">
							<input type="email" name="email" class="form-control" placeholder="Subscribe Our Newsletter">
							<button type="submit"><i class="fa fa-long-arrow-right"></i></button>
						</form>
						<div class="subscribe-alert"></div>
						<div class="clearfix"></div>
						<p>Get the latest updates and opportunities.</p>
 					</div>
				</div><!-- .col-md-3 end -->
				<div class="clearfix"></div>
			</div>
		</div><!-- .container end -->
	</div><!-- .footer-widget end -->
	
	<!-- Copyrights
	============================================= -->
	<div class="footer--bar">
 			<div class="row">
                <div class="col-12 col-md-12 col-md-12 text--center footer--copyright">
					<div class="copyright">
                         <a href="https://www.hyperspace.africa">hyperspace</a> <br>
                         <span>© 2019</span>
					</div>
                </div>
 			</div>
		 <!-- .row end -->
	</div><!-- .footer-copyright end -->
</footer>



<div id="back-to-top" class="backtop"><i class="fa fa-long-arrow-up"></i></div>
 </div><!-- #wrapper end -->

 <!--Modal: modalPush-->
<div class="modal fade " id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-notify modal-info" role="document">
    <!--Content-->
    <div class="modal-content contact-box text-center">
      <!--Header-->
      <div class="modal-header d-flex justify-content-center">
                        <h3>Want to Build Something?</h3>
      </div>

      <!--Body-->
      <form class="mb-0">
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="contact-name" id="contact-name" placeholder="Name" required="">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col">
                                <input type="email" class="form-control" name="contact-email" id="contact-email" placeholder="Email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <textarea class="form-control" name="contact-message" id="contact-message" rows="2" placeholder="What do you want to build?"></textarea>
                            </div>
                        </div>
                       <div class="row">
                            <div class="col-12 col-sm-12 col-md-12">
                                <div class="contact-result"></div>
                            </div>
                        </div>
                    </form>
      <!--Footer-->
      <div class="modal-footer flex-center">
        <a href="" id="modalbtn" class="btn--primary  btn--rounded waves-effect" data-dismiss="modal">Cancel</a> 
        <a id="modalbtn" class=" btn--primary  btn--rounded" href="">Send Message</a>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: modalPush-->

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
<!-- RS5.0 Core JS Files -->
<script src="assets/revolution/js/jquery.themepunch.tools.min.js?rev=5.0"></script>
<script src="assets/revolution/js/jquery.themepunch.revolution.min.js?rev=5.0"></script>
<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<!-- RS Configration JS Files -->
<script src="assets/js/rsconfig.js"></script>
</body>
</html>