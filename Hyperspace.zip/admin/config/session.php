<?php
// Start the session
session_start();

$_SESSION["registration_error"];
$_SESSION["login_error"];
$_SESSION["hackathon_message"];
$_SESSION["user_email"];
