<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<!-- Document Meta
    ============================================= -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--IE Compatibility Meta-->
<meta name="author" content="zytheme"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="assets/images/favicon/favicon.png" rel="icon">

<!-- Fonts
    ============================================= -->
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,400i,500,500i,600,600i,700,700i,800%7CRoboto:300i,400,400i,500,500i,700" rel="stylesheet" type="text/css">

<!-- Stylesheets
    ============================================= -->
<link href="assets/css/external.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">

<!-- RS5.0 Main Stylesheet -->
<link rel="stylesheet" type="text/css" href="assets/revolution/css/settings.css">
<link rel="stylesheet" type="text/css" href="assets/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="assets/revolution/css/navigation.css"> 
<!-- <link rel="stylesheet" type="text/css" href="assets/css/library/bootstrap.css">  -->


    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css">
    <script type="text/javascript" src="assets/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/owl.carousel.min.js"></script> 

<!-- Document Title
    ============================================= -->
<title>Hyperspace</title>
</head>
<body>
<div class="preloader">
	<div class="reverse-spinner"></div>
</div><!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="wrapper clearfix">
<header id="navbar-spy" class="header header-1 header-transparent">
	<nav id="primary-menu" class="navbar navbar-expand-lg navbar-light navbar-bordered">
		<div class="container">
			<a class="navbar-brand" href="index.html">
				<img class="logo logo-light" src="assets/images/logo/logo.png" alt="Hyperspace Logo"> 
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
							
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="navbarContent">
				<ul class="navbar-nav ml-auto">
				<!-- Home Menu-->
<li class=" ">
    <a href="./index.html"  class=" menu-item">Home</a>
</li>
<!-- li end -->

<!-- Community Menu -->
<li class="">
    <a href="#"  class=" menu-item" data-hover="pages">Community</a>
</li>
<!-- li end -->
<!-- Hackathons Menu-->
<li class="">
    <a href="#" class=" menu-item" >Hackathons</a>
   
</li>
<!-- li end -->
<!-- Resources Menu-->
<li class="">
    <a href="#"  class=" menu-item">Resources</a>
    
</li>
<!-- li end -->
				<div class="module-container">
				<!-- Module Attend  -->
<div class="module module-consultation pull-left">
	<a class="btn" href="#">Attend</a>
</div>				


			</div>
			<!-- /.navbar-collapse -->
		</div>
		<!-- /.container -->
	</nav>
</header>
<!-- Header  
====================================== -->



<!-- Page Title #1
============================================= -->
<section id="page-title" class="page-title bg-overlay bg-overlay-dark bg-parallax">
	<div class="bg-section">
		<img src="assets/images/page-titles/4.jpg" alt="Background"/>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-8 offset-lg-2">
				<div class="title  text-center">
                    <div class="title--heading">
                        <h1>Frequently Asked Questions</h1>
                    </div>
					<div class="clearfix"></div>
					<ol class="breadcrumb d-flex justify-content-center">
						<li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
						<li class="breadcrumb-item"><a href="index-2.html">about</a></li>
						<li class="breadcrumb-item active" aria-current="page">FAQs</li>
					</ol>
				</div><!-- .title end -->
			</div><!-- .col-lg-8 end -->
		</div><!-- .row end -->
	</div><!-- .container end -->
</section><!-- #page-title end -->

<!-- Accordion #1
============================================= -->
<section id="faqs" class="bg-white">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12 col-lg-3">
				<!-- Categories
============================================= -->
<div class="widget widget-categories">
	<div class="widget-content">
		<ul class="list-unstyled">
			<li class="active"><a href="#">All services</a></li>
			<li><a href="#">Protection & Security</a></li>
			<li><a href="#">Licensed Exchange</a></li>
			<li><a href="#">Recurring Buys</a></li>
			<li><a href="#">Unlimited Free Transfers</a></li>
			<li><a href="#">Multi Currency Accounts</a></li>
			<li><a href="#">Blockchain Smart Contracts</a></li>
		</ul>
	</div>
</div>

<!-- Info
============================================= -->
<div class="widget widget-info">
	<div class="widget--content">
		<div class="info--title pull-left">
			Download<br>Our Brochures
		</div>
		<div class="info--icon pull-right">
			<img src="assets/images/icons/pdficon.jpg" alt="icon">
		</div>
	</div>
</div> <!-- .widget-info end -->			</div><!-- .col-lg-3 end -->
			<div class="col-sm-12 col-md-12 col-lg-9">
				<div class="accordion accordion-1" id="accordion01">
					<!-- Panel 01 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-1">Which Plan Is Right For Me?</a>
						</div>
						<div id="collapse01-1" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 02 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-2">Do I have to commit to a contract? </a>
						</div>
						<div id="collapse01-2" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 03 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-3">What if I pick the wrong plan?</a>
						</div>
						<div id="collapse01-3" class="collapse show" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 04 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-4">Any contracts or commitments?</a>
						</div>
						<div id="collapse01-4" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 05 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-5">What are my payment options?</a>
						</div>
						<div id="collapse01-5" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 06 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion06" href="#collapse01-6">How does the free trial work?</a>
						</div>
						<div id="collapse01-6" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 07 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-7">When should I receive my money?</a>
						</div>
						<div id="collapse01-7" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 08 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-8">How do I cancel my transaction?</a>
						</div>
						<div id="collapse01-8" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 09 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-9">Why does my transaction take so long?</a>
						</div>
						<div id="collapse01-9" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 10 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-10">Can I pay for 12 months in advance?</a>
						</div>
						<div id="collapse01-10" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					
					<!-- Panel 11 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-11">If I have questions, where can I find answers?</a>
						</div>
						<div id="collapse01-11" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 12 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-12">What happens to my data if I cancel?</a>
						</div>
						<div id="collapse01-12" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
					<!-- Panel 13 -->
					<div class="card">
						<div class="card-heading">
							<a class="card-link collapsed" data-toggle="collapse" data-parent="#accordion01" href="#collapse01-13">Is my data safe?</a>
						</div>
						<div id="collapse01-13" class="collapse" data-parent="#accordion01">
							<div class="card-body">Trends, vision dominates a lot of our subconscious interpretation of the world around us. On top it, pleasing images create a better user experience. Rounding up a bunch of specific designs.Trends, vision dominates a lot of our subconscious interpretation of the world around us. </div>
						</div>
					</div>
				</div>
				<!-- End .Accordion-->
			</div><!-- .col-lg-9 end -->
		</div><!-- .row end -->
	</div><!-- .container end -->
</section><!-- #faq end -->






<!-- Footer #1
============================================= -->
<footer id="footer" class="footer footer-1">
	<!-- Widget Section
	============================================= -->
	<div class="footer-widget">
		<div class="container">
			<div class="row clearfix">
				<div class="col-12 col-md-6 col-lg-3 footer--widget widget-about">
					<div class="widget-content">
						<img class="footer-logo" src="assets/images/logo/logo.png" alt="logo">
						<p style="color: #969696">Grooming students into experts, ready to challenge the ever growing tech-sphere. Finding talents around Africa and making them stars. </p>
						<div class="social-icons">
							<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
							<a href="https://twitter.com/HyperspaceAfric" class="twitter"><i class="fa fa-twitter"></i></a>
                            <a href="https://instagram.com/hyperspaceafrica" class="instagram"><i class="fa fa-instagram"></i></a>
							<a href="#" class="slack"><i class="fa fa-slack"></i></a>
							<a href="#" class="github"><i class="fa fa-github"></i></a>
                        </li>
						</div>
					</div>
				</div><!-- .col-md-3 end -->
				<div class="col-12 col-sm-4 col-md-6 col-lg-2 footer--widget widget-links">
					<div class="widget-title">
						<h5>About</h5>
					</div>
					<div class="widget-content">
						<ul>
							<li><a href="./about.html">About Us</a></li>
							<li><a href="./meet-the-team.html">Meet Our Team</a></li>
							<li><a href="#">Latest News</a></li>
							<li><a href="" data-toggle="modal" data-target="#modalPush">Contact Us</i></li>
						</ul>
					</div>
				</div><!-- .col-md-2 end -->
				
				<div class="col-12 col-sm-8 col-md-6 col-lg-2 footer--widget widget-links widget-links-inline">
					<div class="widget-title">
						<h5>Resources</h5>
					</div>
					<div class="widget-content">
						<ul>
							<li><a href="#">Code of Conduct</a></li>
							<li><a href="#">Find a Hackathon</a></li>					
						</ul>
					</div>
				</div><!-- .col-md-4 end -->

				<div class="col-12 col-sm-8 col-md-6 col-lg-2 footer--widget widget-links widget-links-inline">
									<div class="widget-title">
										<h5>Info</h5>
									</div>
									<div class="widget-content">
										<ul>
											<li><a href="#">Become an Organiser</a></li>
											<li><a href="#">FAQs</a></li>
										</ul>
									</div>
								</div><!-- .col-md-4 end -->

				<div class="col-12 col-md-6 col-lg-3 footer--widget widget-newsletter">
					<div class="widget-title">
						<h5>Stay Updated</h5>
					</div>
					<div class="widget-content">
						<form class="form-newsletter mailchimp">
							<input type="email" name="email" class="form-control" placeholder="Subscribe Our Newsletter">
							<button type="submit"><i class="fa fa-long-arrow-right"></i></button>
						</form>
						<div class="subscribe-alert"></div>
						<div class="clearfix"></div>
						<p style="color: #969696">Get the latest updates and opportunities.</p>
 					</div>
				</div><!-- .col-md-3 end -->
				<div class="clearfix"></div>
			</div>
		</div><!-- .container end -->
	</div><!-- .footer-widget end -->
	
	<!-- Copyrights
	============================================= -->
	<div class="footer--bar">
 			<div class="row">
                <div class="col-12 col-md-12 col-md-12 text--center footer--copyright">
					<div class="copyright">
                         <a href="https://www.hyperspace.africa">hyperspace</a> <br>
                         <span>© 2019</span>
					</div>
                </div>
 			</div>
		 <!-- .row end -->
	</div><!-- .footer-copyright end -->
</footer>



<div id="back-to-top" class="backtop"><i class="fa fa-long-arrow-up"></i></div>
 </div><!-- #wrapper end -->


<!--Modal: modalPush-->
<div class="modal fade " id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-notify modal-info" role="document">
    <!--Content-->
    <div class="modal-content contact-box text-center">
      <!--Header-->
      <div class="modal-header d-flex justify-content-center">
                        <h3>Want to Build Something?</h3>
      </div>

      <!--Body-->
      <form class="mb-0">
                        <div class="row">
                            <div class="col">
                                <input type="text" class="form-control" name="contact-name" id="contact-name" placeholder="Name" required="">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col">
                                <input type="email" class="form-control" name="contact-email" id="contact-email" placeholder="Email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <textarea class="form-control" name="contact-message" id="contact-message" rows="2" placeholder="What do you want to build?"></textarea>
                            </div>
                        </div>
                       <div class="row">
                            <div class="col-12 col-sm-12 col-md-12">
                                <div class="contact-result"></div>
                            </div>
                        </div>
                    </form>
      <!--Footer-->
      <div class="modal-footer flex-center">
        <a href="" id="modalbtn" class="btn--primary  btn--rounded waves-effect" data-dismiss="modal">Cancel</a> 
        <a id="modalbtn" class=" btn--primary  btn--rounded" href="">Send Message</a>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: modalPush-->


<!-- Footer Scripts
============================================= -->
<!-- <script type="text/javascript">
   
    $('#exampleModal').on('show.bs.modal', function (event) {
  var recipient = button.data('hello@hyperspace.africa') 
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
</script> -->
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/functions.js"></script>
<!-- RS5.0 Core JS Files -->
<script src="assets/revolution/js/jquery.themepunch.tools.min.js?rev=5.0"></script>
<script src="assets/revolution/js/jquery.themepunch.revolution.min.js?rev=5.0"></script>
<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<!-- RS Configration JS Files -->
<script src="assets/js/rsconfig.js"></script>
</body>
</html>